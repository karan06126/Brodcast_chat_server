package com.virtusa.bean;

import java.util.*;  
import javax.persistence.*;  
import org.hibernate.*;  
import org.hibernate.boot.Metadata;  
import org.hibernate.boot.MetadataSources;  
import org.hibernate.boot.registry.StandardServiceRegistry;  
import org.hibernate.boot.registry.StandardServiceRegistryBuilder; 

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	StandardServiceRegistry ssr=new StandardServiceRegistryBuilder().configure("Hibernate.cfg.xml").build();  
        Metadata meta=new MetadataSources(ssr).getMetadataBuilder().build();  
          
        SessionFactory factory=meta.getSessionFactoryBuilder().build();  
        Session session=factory.openSession();  
                    
    //Hibernate Named Query    
           TypedQuery query = session.getNamedQuery("findUserByName");    
            query.setParameter("fullName","Karan Singh");   
                    
            List<RegisterBean> user=query.getResultList();   
            
    Iterator<RegisterBean> itr=user.iterator();    
     while(itr.hasNext()){    
    RegisterBean e=itr.next();    
    System.out.println(e);    
     }    
    session.close();
    }
}