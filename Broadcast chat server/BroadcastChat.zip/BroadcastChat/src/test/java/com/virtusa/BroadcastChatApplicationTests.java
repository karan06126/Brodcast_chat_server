package com.virtusa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BroadcastChatApplicationTests {

	@Test
	void contextLoads() {
	}

}
