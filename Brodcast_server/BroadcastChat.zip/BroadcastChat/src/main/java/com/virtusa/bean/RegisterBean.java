package com.virtusa.bean;

import javax.persistence.*;

@NamedQueries(  
	    {  
	        @NamedQuery(  
	        name = "findUserByName",  
	        query = "from RegisterBean u where u.fullName = :fullName"  
	        )  
	    }  
	) 


@Entity
@Table(name= "users")
public class RegisterBean {
 
 @Id
 @GeneratedValue(strategy = GenerationType.IDENTITY)
 private Long id;
 @Column(name = "full_name", nullable = false, length = 20)
private String fullName;
 
 @Column(nullable=false ,unique =true)
 private String email;
 private String userName;
 
 @Column(nullable=false ,length =64)
 private String password;
 
 
public Long getId() {
		return id;
	}
public void setId(Long id) {
		this.id = id;
	}

public String getFullName() {
	return fullName;
}
public void setFullName(String fullName) {
	this.fullName = fullName;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getUserName() {
	return userName;
}
public void setUserName(String userName) {
	this.userName = userName;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}

}