package com.virtusa.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.virtusa.bean.RegisterBean;


public interface UserRepository extends JpaRepository<RegisterBean, Long> {
	@Query("SELECT u FROM RegisterBean u WHERE u.email = ?1")
    public RegisterBean findByEmail(String email);
	 
}
